# Implementation

## Folder Structure

| Folder | Description |
| --- | --- |
| inc | All header files |
| src | Main source code for system |
| test | All source code and data for testing purposes |
| build | Build output |
