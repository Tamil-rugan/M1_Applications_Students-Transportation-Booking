#ifndef __HEADER_H__
#define __HEADER_H__

#include <stdio.h>
#include <stdlib.h>

void details(int);
int seat(int);
int cal(int, int, int);
void bill(int, int);

#endif